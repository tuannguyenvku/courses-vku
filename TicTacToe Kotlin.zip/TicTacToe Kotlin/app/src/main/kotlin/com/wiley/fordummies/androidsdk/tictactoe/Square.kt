package com.wiley.fordummies.androidsdk.tictactoe

/**
 * Created by adamcchampion on 2017/09/05.
 */
class Square(var x: Int, var y: Int) {

}
